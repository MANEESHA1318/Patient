package com.example.PatientManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
