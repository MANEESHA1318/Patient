package com.example.PatientManagement.Model;

import java.sql.Date;
import java.util.Map;

public class LabTest {
	private String testName;
	private Date testDate;
	private Map<String, Double> testResults;
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public Date getTestDate() {
		return testDate;
	}
	public void setTestDate(Date testDate) {
		this.testDate = testDate;
	}
	public Map<String, Double> getTestResults() {
		return testResults;
	}
	public void setTestResults(Map<String, Double> testResults) {
		this.testResults = testResults;
	}
	
}
