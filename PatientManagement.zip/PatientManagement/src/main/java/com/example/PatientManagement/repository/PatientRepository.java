package com.example.PatientManagement.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.PatientManagement.Model.Patient;

public interface PatientRepository extends MongoRepository<Patient, String> {

}
